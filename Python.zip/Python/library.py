def test():
    print 1